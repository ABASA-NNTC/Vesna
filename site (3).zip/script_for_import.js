// function showf() {
//     document.getElementsByClassName('main_import')[0].style.display="flex";
//     document.getElementsByClassName('main_what')[0].style.display="none";
// }

// function showcad() {
//     document.getElementsByClassName('main_import')[0].style.display="flex";
//     document.getElementsByClassName('main_what')[0].style.display="none";
// }
