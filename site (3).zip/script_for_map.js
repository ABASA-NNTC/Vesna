// Переменные с координатами карт
let el_m = [55.042136, 82.91699];
let el1_m = [54.042136, 82.91699];
let el2_m = [53.042136, 82.91699];
let el3_m = [52.042136, 82.91699];
let map_obj;
let data;

// Функция для отображения карты
DG.then(function() {
    map_obj = DG.map('map', {
        center: el_m,
        zoom: 14
    });

    data = [
        {
            "type": "Feature",
            "properties": {
                "info": "Я маркер"
            },
            "geometry": {
                "type": "Point",
                "coordinates": [82.91799, 55.043136]
            }
        },
        {
            "type": "Feature",
            "properties": {
                "info": "Я полигон"
            },
            "geometry": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [82.91699, 55.042136],
                        [82.917522, 55.040187],
                        [82.918063, 55.040235],
                        [82.917540, 55.042184],
                        [82.91699, 55.042136]
                    ]
                ]
            }
        }
    ];

    DG.geoJson(data, {
        onEachFeature: function (feature, layer) {
            layer.bindPopup(feature.properties.info);
        }
    }).addTo(map_obj);
});

//Функция для смена координат №1
function Change_map_el1() {
    let el_m = el1_m;
    map_obj.panTo(el1_m);
};

// Функция для смены координат №2
function Change_map_el2() {
    let el = el2_m;
    map_obj.panTo(el2_m);
};

// Функция для смены координат №3
function Change_map_el3() {
    let el = el3_m;
    map_obj.panTo(el3_m);
};

//Функция показывающая/скрывающая блоки
function showButton2() {
    document.getElementsByClassName('elements2')[0].style.display="block";
    document.getElementsByClassName('elements')[0].style.display="none";
}

//Функция показывающая/скрывающая блоки
function showButton1() {
    document.getElementsByClassName('elements2')[0].style.display="none";
    document.getElementsByClassName('elements')[0].style.display="block";
}

// Переменные для хранения и обработки checkbox
let num_f = [];
let num_c = [];
let num_f_id=[];
let num_c_id=[];

// Функциb checkbox
function fun1_f() {
var chbox;
chbox=document.getElementById('el1_f');
    if (chbox.checked) {
        console.log('Выбран 1 поле');
        num_f[0] = 1;
        let f1_id='001'
        num_f_id[0] = f1_id;
    }
    if(chbox.checked==false) {
        num_f[0] = null;
        num_f_id[0]= null;
    }
}

function fun2_f() {
var chbox;
chbox=document.getElementById('el2_f');
    if (chbox.checked) {
        console.log('Выбран 2 поле');
        num_f[1] = 2;
        let f2_id='002';
        num_f_id[1] = f2_id;
    }
    if(chbox.checked==false) {
        num_f[1]=null;
        num_f_id[1] = null;
    }
}

function fun3_f() {
var chbox;
chbox=document.getElementById('el3_f');
    if (chbox.checked) {
        console.log('Выбран 3 поле');
        num_f[2] = 3;
        let f3_id='003';
        num_f_id[2] = f3_id;
    }
    if(chbox.checked==false) {
        num_f[2]=null;
        num_f_id[2]=null;
    }
}

function fun1_c() {
var chbox;
chbox=document.getElementById('el1_c');
    if (chbox.checked) {
        console.log('Выбран 1 кадастр');
        num_c[0]=1;
        let c1_id='52:43:0100016:41';
        num_c_id[0]=c1_id;
    }
    if(chbox.checked==false) {
        num_c[0]=null;
        num_c_id[0]=null;
    }
}

function fun2_c() {
var chbox;
chbox=document.getElementById('el2_c');
    if (chbox.checked) {
        console.log('Выбран 2 кадастр');
        num_c[1]=2;
        let c2_id ='52:43:0100016:42';
        num_c_id[1]=c2_id
    }
    if(chbox.checked==false) {
        num_c[1]=null;
        num_c_id[1]=null;
    }
}

function fun3_c() {
var chbox;
chbox=document.getElementById('el3_c');
    if (chbox.checked) {
        console.log('Выбран 3 кадастр');
        num_c[2]=3;
        let c3_id = '52:43:0100016:43';
        num_c_id[2]=c3_id;
    }
    if(chbox.checked==false) {
        num_c[2]=null;
        num_c_id[2]=null;
    }
}

// Функция для кнопки "Выбрать всё"
function fun_all() {
var chbox;
chbox=document.getElementById('all_f');
    if (chbox.checked) {
        document.getElementById('el1_f').click();
        document.getElementById('el2_f').click();
        document.getElementById('el3_f').click();
        document.getElementById('el1_c').click();
        document.getElementById('el2_c').click();
        document.getElementById('el3_c').click();
    }
}

// Функция показывающая карты, зависящая от checkbox
function showField() {
    if (num_f.includes(1)){
        Change_map_el1();
    }
    if (num_f.includes(2)){
        Change_map_el2();
    }
    if (num_f.includes(3)){
        Change_map_el3();
    }

    if (num_c.includes(1)){
        Change_map_el1();
    }
    if (num_c.includes(2)) {
        Change_map_el2();
    }
    if (num_c.includes(3)) {
        Change_map_el3();
    }
    console.log('id выбранных полей: ' + num_f_id);
    console.log('Номера выбранных кадастров: ' + num_c_id);
}



// Кнопка "Подробнее"
function info_el1_f() {
    alert('На огороде растут ягоды');
}

function info_el2_f() {
    alert('На грядке растёт морковь');
}

function info_el3_f() {
    alert('На поле растёт пшеница');
}

// Функция для сброса карт(перезагрузка страницы)
function reload() {
    location.reload();
}

let cad1;
cad1 = {"type": "FeatureCollection", "features": [{"type": "Feature", "geometry": {"type": "Polygon", "coordinates": [[[44.45956, 55.761987], [44.459587, 55.761921], [44.464114, 55.761734], [44.464626, 55.761674], [44.46503, 55.761573], [44.46645, 55.761552], [44.467824, 55.761456], [44.46804, 55.761401], [44.468094, 55.760046], [44.467977, 55.759894], [44.467591, 55.759723], [44.468399, 55.759536], [44.468929, 55.75946], [44.468947, 55.759364], [44.468821, 55.759333], [44.46733, 55.759632], [44.466863, 55.759409], [44.465848, 55.759622], [44.467186, 55.756958], [44.468812, 55.754885], [44.469055, 55.754703], [44.469459, 55.754506], [44.470546, 55.754395], [44.469944, 55.754637], [44.469917, 55.755057], [44.470034, 55.755391], [44.470277, 55.755694], [44.471885, 55.756857], [44.472873, 55.759111], [44.473133, 55.759505], [44.473403, 55.759758], [44.471786, 55.76038], [44.47069, 55.760749], [44.470088, 55.760895], [44.470196, 55.761042], [44.469342, 55.76131], [44.469369, 55.761204], [44.469558, 55.761168], [44.469585, 55.761102], [44.469387, 55.761006], [44.469387, 55.760835], [44.469208, 55.760668], [44.469154, 55.760506], [44.469064, 55.760456], [44.468938, 55.760471], [44.468803, 55.760531], [44.468785, 55.760764], [44.468669, 55.7609], [44.468758, 55.760926], [44.468992, 55.760845], [44.469127, 55.76085], [44.469226, 55.760946], [44.469127, 55.761229], [44.469235, 55.76134], [44.468202, 55.761633], [44.468103, 55.761542], [44.466261, 55.762007], [44.465075, 55.762225], [44.464375, 55.762285], [44.463189, 55.76229], [44.461482, 55.762179]], [[44.47042, 55.758494], [44.470519, 55.758358], [44.470223, 55.758262], [44.470447, 55.758373], [44.470366, 55.758454], [44.470169, 55.758282], [44.470115, 55.758287], [44.470322, 55.758479]], [[44.470142, 55.758575], [44.469998, 55.758489], [44.469675, 55.758429], [44.470043, 55.75857], [44.469657, 55.758479], [44.46963, 55.758515], [44.469971, 55.758611]]]}, "properties": {"KN": "52:43:0100016:41"}}, {"type": "Feature", "geometry": {"type": "Polygon", "coordinates": [[[44.473435, 55.759721], [44.473201, 55.759503], [44.472923, 55.759079], [44.471943, 55.75684], [44.470335, 55.755677], [44.470093, 55.755374], [44.470003, 55.755121], [44.470003, 55.754656], [44.47153, 55.754004], [44.471476, 55.753877], [44.471791, 55.753685], [44.472033, 55.753766], [44.472186, 55.753716], [44.47259, 55.753812], [44.472689, 55.753802], [44.472761, 55.753741], [44.472761, 55.753524], [44.473749, 55.753326], [44.474243, 55.753311], [44.474396, 55.753443], [44.474405, 55.753564], [44.474342, 55.753655], [44.474108, 55.753695], [44.474054, 55.753771], [44.474297, 55.753908], [44.474414, 55.753837], [44.474701, 55.753812], [44.475016, 55.753635], [44.475375, 55.75364], [44.475591, 55.753357], [44.476192, 55.753372], [44.476354, 55.753433], [44.476758, 55.753488], [44.476929, 55.753635], [44.477154, 55.753655], [44.477342, 55.753625], [44.477333, 55.753771], [44.477252, 55.753832], [44.477288, 55.754039], [44.477234, 55.75416], [44.477001, 55.754378], [44.476911, 55.754585], [44.476498, 55.754909], [44.476318, 55.755303], [44.475986, 55.755475], [44.476103, 55.755551], [44.476112, 55.755707], [44.476192, 55.755748], [44.4763, 55.755682], [44.476237, 55.755576], [44.476552, 55.755485], [44.476624, 55.755187], [44.476749, 55.755192], [44.47683, 55.755353], [44.476947, 55.755374], [44.477001, 55.755338], [44.476956, 55.755161], [44.477019, 55.754934], [44.477073, 55.754934], [44.477127, 55.75504], [44.477127, 55.755207], [44.477199, 55.755262], [44.47727, 55.755247], [44.477145, 55.758119], [44.476174, 55.758644]]]}, "properties": {"KN": "52:43:0100016:54"}}]}

